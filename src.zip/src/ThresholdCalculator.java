import java.util.*;

public class ThresholdCalculator {
	
	public Scorer s; 
	public char[][] motif;
	public Threshold[] t;
	
	public ThresholdCalculator(char[][] motif, Scorer s){
		this.s = s;
		this.motif = motif;
	}
	
	public Score[] calcMotifScore(){
		Score[] mfscore = new Score[motif.length];
		for(int i=0; i<motif.length; i++)
			mfscore[i] = s.likelihood(motif[i], 0, motif[i].length-1);
		return mfscore;
	}
	


	public double[][] calcNumGrid(Score[] mfscore){
		double[][] scores = new double[mfscore[0].score.length][mfscore.length];
		for(int i=0; i<mfscore[0].score.length; i++)
			for(int j=0; j<mfscore.length; j++)
				scores[i][j] = mfscore[j].score[i];
		return scores;
	}
	
	public double[][] calcNumGrid(double[] lb, double[] ub, int[] n){ // Have to be of equal dimension
		double[] del = new double[lb.length];
		for(int i=0; i<del.length; i++){
			del[i] = (ub[i]-lb[i])/n[i];
		}
		double[][] scores = new double[del.length][];
		for(int i=0; i<scores.length; i++){
			scores[i] = new double[n[i]+1];
			for(int j=0; j<scores[i].length; j++)
				scores[i][j] = lb[i]+j*del[i];
		}
		return scores;
	}	
	
	Threshold[] calcMotifSpec(char[] seq) throws Exception{
		
		Mapper mp = new Mapper(seq,this.s,this.t[t.length-1]);
		Vector<Hit> hits = mp.map();
		
		for(int i=0; i<t.length; i++)
			t[i].hits = 0;
		for(int i=0; i<hits.size(); i++ )
			for(int j=0; j<t.length; j++)
				if(hits.get(i).score.greaterThan(t[j].score))
					t[j].hits++;
		for(int i=0; i<t.length; i++)
			t[i].spec = seq.length/t[i].hits;
		return t;
	}
	
	
	double calcSense(double[][] mfscore, double[] s){
		int count = 0;
		for(int i=0; i<mfscore.length; i++){
			boolean b = true;
			for(int j=0; j<s.length; j++)
				if(mfscore[i][j]>s[j]==false){
					b = false; break;
				}
			if(b) count++;
		}
		return (100.0*count)/mfscore.length;
	}
	
	Threshold[] calcMotifSense(double[][] scores) {
		int n = 1;
		for(int i=0; i<scores.length; i++){
			Arrays.sort(scores[i]);
			n *= scores[i].length;
		}
		
		this.t = new Threshold[n];
		int[] a = new int[scores.length];
		for(int count=0; count<n; count++)
		{
			int j = scores.length-1;
            while(a[j]==scores[j].length-1) {
                a[j] = 0;
                j--;
            }
            a[j]++;			
			
            double[] d = new double[scores.length]; 
            for(int k=0; k<scores.length; k++)
            	d[k] = scores[k][a[k]];
            t[count] = new Threshold(d);
            t[count].sense = calcSense(scores, t[count].score.score);
		}
		
		Arrays.sort(t, new Comparator<Threshold>(){
			@Override
			public int compare(Threshold t0, Threshold t1) { //reverse sorting
				if(t0.sense>t1.sense) return 0;
				else if(t0.sense<t1.sense) return 1;
				else return 0;
			}});		
		
	    return t;
	}
	
	Threshold calcMotifThreshold(double sense){	
		int pos = 0;
		double max = 0;
	    for(int i=0; i<t.length; i++)
	        if(t[i].sense>=sense && max<t[i].spec) {
	            pos = i;
	            max = t[i].spec;
	        }
	    return t[pos];
	}
}
