import java.io.*;
import java.text.DecimalFormat;
import java.util.*;
import edu.rit.pj.ParallelRegion;
import edu.rit.pj.ParallelTeam;
import edu.rit.util.LongRange;

public class MotifScanner{

	public ArrayList<Model> models =  new ArrayList<Model>();	
	public List[] hits;
	public Scorer s;
	public char[] dna;
	public String feature = "bs";
	public String source = "Mapper";

	//Different Input/Model -> Matrix -> Different Scoring -> Different Threshold 
	public void run(String[] param){
		try{
			getMatrix(param[0]);
			runMapper(param[1],param[2]);
		}catch(Exception e){
			e.printStackTrace();
		}
	}

	public void getMatrix(String param) throws Exception{		
		ArrayList<Record> tfr = (ArrayList<Record>)new RecordFileReader(new MatrixReader()).readRecordFile(param);
		for(int i=0; i<tfr.size(); i++){
			TransfacRecord r = (TransfacRecord)tfr.get(i);
			double[][] wm = N.transpose(r.mat); // Rows are position
			for(int j=0; j<wm.length; j++) // Prior add
				N.add(wm[j],1);
			int n = wm.length;
			int[][] edge = new IndependenceFinder().findDependency(n);
			DMHModel m = new DMHModel(n,4,edge);
			m.prior = m.WM = N.normd(wm);
			//m.prior = m.WM = N.log2(N.normd(wm));
			//r.th[0] = Math.log(r.th[0])/Math.log(2);
			m.th = new Threshold(r.th);
			m.filter = m.th.score.score[0];
			m.name = r.ac;
			m.source = this.source;
			m.feature = this.feature;
			m.table = new LookupTable(m.filter,m);
			m.table.createDMHT();
			models.add(m);				
		}	
	}	

	public void runMapper(String param0, String param1) throws Exception{
		try{
			BufferedReader br = new BufferedReader(new FileReader(param0));
			BufferedWriter bw = new BufferedWriter(new FileWriter(param1));

			char[] dna = null;
			String line = null, seqname = null;
			Vector<List> hits;
			while((line = br.readLine())!=null){
				if(line.startsWith(">")){
					seqname = line.substring(1);
					System.out.println(seqname);
					continue;
				}
				dna = N.nc(line.toCharArray());
				hits = runMap(dna);
				for(int i=0; i<hits.size(); i++)
					new RecordFileWriter(new HitGFFWriter()).writeRecordFile(bw,hits.get(i),seqname,'+');			
				dna = N.rc(dna);
				hits = runMap(dna);
				for(int i=0; i<hits.size(); i++)
					new RecordFileWriter(new HitGFFWriter()).writeRecordFile(bw,hits.get(i),seqname,'-');			
			}		
			bw.flush();
			bw.close();
			br.close();			

		}catch(IOException e){
			System.out.println(e);
		}
	}	

	public Vector<List> runMap(char[] seq) throws Exception{
		this.hits = new List[models.size()];
		this.dna = seq;
		//new ParallelTeam().execute (new ParallelRegion()
		//{
		//public void run()
		//{
		//LongRange range = new LongRange(0,models.size()-1).subrange (getThreadCount(), getThreadIndex());
		//int start=(int)range.lb(), end=(int)range.ub();
		int start = 0, end = models.size()-1; 
		for(int i=start; i<end+1; i++){
			Model m = models.get(i);
			DMHPriorScorer dps = new DMHPriorScorer((DMHModel)m);
			hits[i] = new Mapper(dna,dps,m.th).map();
		}
		//}
		//});
		Vector<List> vL = new Vector<List>(hits.length); 
		for(int i=0; i<hits.length; i++)
			vL.add(i,hits[i]);
		return vL;
	}

	public void trainModel(String param) throws Exception{
		//RecordReader rdr = new DMFReader();
		RecordReader rdr = new ThresholdReader();
		ArrayList<Record> tfr = (ArrayList<Record>)new RecordFileReader(rdr).readRecordFile(param);
		for(int i=0; i<tfr.size(); i++){
			TransfacRecord r = (TransfacRecord)tfr.get(i);
			if(r.bs == null) continue;

			char[][] bs = r.getNS();
			int n = r.getN();
			int[][] edge = new CliqueDependencyFinder().findDependency(n);
			DMHModel m = new DMHModel(n,edge);
			m.train(bs);

			char[] bg = null; //Background seq
			double sense = 0; //Sense
			this.s = new DMHPriorScorer(m);
			ThresholdCalculator tc = new ThresholdCalculator(bs,s);
			Score[] mfprior = tc.calcMotifScore();
			this.s = new DMHLikeScorer(m);
			tc = new ThresholdCalculator(bs,s);
			Score[] mfscore = tc.calcMotifScore();
			double[][] scores = tc.calcNumGrid(mfscore);
			tc.calcMotifSense(scores);
			tc.calcMotifSpec(bg);			
			m.th = tc.calcMotifThreshold(sense);

			Integer[] midx = N.sortIndex(mfscore,Score.getSumComp());
			Integer[] pidx = N.sortIndex(mfprior,Score.getSumComp());

			if(Arrays.equals(midx,pidx)==false){
				System.out.println("ASSUMPTION IS NOT CORRECT");
			}
			m.filter = mfprior[pidx[0]].sum;
			m.table = new LookupTable(m.filter,m);
			//m.table.createDMHT();
			m.name = r.ac;
			models.add(m);
		}	
	}		
}
