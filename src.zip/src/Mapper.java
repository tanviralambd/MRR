import java.util.*;

import edu.rit.pj.*;
import edu.rit.util.LongRange;

public class Mapper{	

	public char[] seq;
	public Scorer s;
	public Threshold threshold;
	public Vector<Hit> hits;

	public Mapper(char[] seq, Scorer s, Threshold threshold){ //Sorted Threshold
		this.seq = seq;
		this.s = s;
		this.threshold = threshold;
		hits = new Vector<Hit>(1000+(int)(.00001*seq.length));		
	}

	public Vector<Hit> pmap() throws Exception
	{	
		new ParallelTeam().execute (new ParallelRegion()
		{
			public void run()
			{
				int L = seq.length, N = s.m.base.length;
				if(L<N) return;
				LongRange range = new LongRange(0,L-N+1).subrange (getThreadCount(), getThreadIndex());
				int start=(int)range.lb(), end=(int)range.ub();
				map(start,end);
			}
		});	
		return hits;
	}	

	public Vector<Hit> map()
	{	
		int start = 0, end = this.seq.length-s.m.base.length+1;
		return map(start,end);
	}	
	
	public Vector<Hit> map(int start, int end)
	{	
		Vector<Hit> thread_hits = new Vector<Hit>(500+(int).000001*(end-start+1));		
	
		
		for(int i=start; i<end+1; i++)
		{
			Score s = this.s.likelihood(seq,i,i+this.s.m.base.length-1);
			if(s.greaterThan(threshold.score))
				thread_hits.add(new Hit(i,s,this.s));
		}
		hits.addAll(thread_hits);
		return hits;
	}	
}

