import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

interface RecordWriter{
	public Record writeRecord(Writer wtr, Record r) throws IOException;
}

interface RecordReader{
	public Record readRecord(Reader rdr) throws IOException;
}

abstract class Record{

}


class RecordFileWriter{
	
	public RecordWriter wtr;
	
	public RecordFileWriter(RecordWriter wtr){
		this.wtr = wtr;
	}
	
	public List<Record> writeRecordFile(String filename, List<Record> gff){		
		try{
			BufferedWriter bw = new BufferedWriter(new FileWriter(filename));
			for(int i=0; i<gff.size(); i++)
				wtr.writeRecord(bw,gff.get(i));
			bw.flush();
			bw.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return gff;
	}	
	
	public List<Record> writeRecordFile(BufferedWriter bw, List<Record> gff, String seqname, char strand){		
		try{
			HitGFFWriter wtr = (HitGFFWriter)this.wtr;
			for(int i=0; i<gff.size(); i++)
				wtr.writeRecord(bw,gff.get(i),seqname,strand);
			bw.flush();
		}catch(Exception e){
			e.printStackTrace();
		}
		return gff;
	}
}


class RecordFileReader{
	
	public RecordReader rdr;
	
	public RecordFileReader(RecordReader rdr){
		this.rdr = rdr;
	}
	
	public List<Record> readRecordFile(String filename){
		ArrayList<Record> tfr = new ArrayList<Record>();
		try{
			BufferedReader br = new BufferedReader(new FileReader(filename));
			Record r;
			while ((r = rdr.readRecord(br)) != null )
				tfr.add(r);
			br.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return tfr;
	}
}


class TransfacRecord extends Record{
	public String ac = null;
	public String na = null;
	public double[][] mat = null;
	public double[] th = null;
	public ArrayList<double[]> wm = null;
	public ArrayList<String> bs = null;
	
	public double[][] getMat(){
		if(wm == null)
			return null;
		double[][] d = new double[wm.size()][];
		for(int i=0; i<wm.size(); i++){
			d[i] = new double[wm.get(i).length];
			for(int j=0; j<wm.get(i).length; j++)
				d[i][j] = wm.get(i)[j];
		}
		return d;
	}
	
	public char[][] getBS(){
		if(bs == null)
			return null;
		char[][] c = new char[bs.size()][];
		for(int i=0; i<bs.size(); i++)
			c[i] = bs.get(i).toCharArray();
		return c;
	}	
	
	public char[][] getNS(){
		char[][] bs = getBS();
		for(int j=0; j<bs.length; j++)
			bs[j] = N.nc(bs[j]);
		return bs;
	}

	public int getN(){
		int n = 0;
		for(int j=0; j<bs.size(); j++){
			if(bs.get(j).length() > n) 
				n = bs.get(j).length();
		}
		return n;
	}

}


class HitGFFWriter implements RecordWriter{

	public Record writeRecord(Writer wtr, Record r, String seqname, char strand) throws IOException {
		Hit h = (Hit)r;
		h.seqname = seqname;
		h.strand = strand;
		return writeRecord(wtr,h);
	}
	
	public Record writeRecord(Writer wtr, Record r) throws IOException {
		Hit h = (Hit)r;
		wtr.write(  h.seqname+"\t"+h.s.m.source	   +"\t"+
h.s.m.feature+":"+ h.s.m.name+"\t"+h.pos     	   +"\t"+
	(h.pos+h.s.m.base.length)+"\t"+h.score.score[0]+"\t"+
				     h.strand+"\n");
		return null;
	}
	
}

class DMFReader implements RecordReader{
	
	public Record readRecord(Reader r) throws IOException{
		BufferedReader br = (BufferedReader) r;
		String line = null;
		String start = "Motif ";
		TransfacRecord tr = new TransfacRecord();
		while((line = br.readLine()) != null){
			if(line.startsWith(start)){
				Scanner sc = new Scanner(line); sc.next();
				tr.ac = sc.next(); sc.close();
				tr.bs = new ArrayList<String>();
				line = br.readLine();
				while(true){
					br.mark(2*line.length());
					line = br.readLine();
					if(line == null || line.startsWith(start)){
						br.reset();
						break;
					}
					sc = new Scanner(line);
					tr.bs.add(sc.next());
					sc.close();
				}
				return tr;
			}	
		}
		return null;
	}
}


class MatrixReader implements RecordReader{
	
	public Record readRecord(Reader r) throws IOException{
		BufferedReader br = (BufferedReader) r;
		String line = null;
		String start = "TF";
		TransfacRecord tr = new TransfacRecord();
		while((line = br.readLine()) != null){
			if(line.startsWith(start)){
				Scanner sc = new Scanner(line); sc.next();
				tr.ac = sc.next(); sc.close();
				sc = new Scanner(br.readLine()); sc.next(); 
				int row = sc.nextInt();  int col = sc.nextInt(); sc.close();
				sc = new Scanner(br.readLine()); sc.next(); 
				tr.th = new double[1]; tr.th[0] = sc.nextDouble();
				tr.mat = IO.readMatrix(br,row,col);
				return tr;
			}
		}
		return null;
	}
}

class ThresholdReader implements RecordReader{
	
	public Record readRecord(Reader r) throws IOException{
		BufferedReader br = (BufferedReader) r;
		String line = null;
		String start = "AC  ";
		String end = "//";
		boolean inRecord = false;
		TransfacRecord tr = new TransfacRecord();
		while((line = br.readLine()) != null){
			if(line.startsWith(start)){
				inRecord = true;
				Scanner sc = new Scanner(line); sc.next(); //AC
				tr.ac = sc.next(); sc.close();
				sc = new Scanner(br.readLine()); sc.next(); //TN
				int row = sc.nextInt();  int col = sc.nextInt(); sc.close();
				sc = new Scanner(br.readLine()); sc.next(); //TF
				tr.na = sc.next(); sc.close();
				sc = new Scanner(br.readLine()); sc.next(); //TH
				tr.th = new double[2];
				tr.th[0] = sc.nextDouble();  tr.th[1] = sc.nextDouble(); sc.close();
				int i = 0;
				tr.bs = new ArrayList<String>();
				do{
					sc = new Scanner(line);
					String bs = sc.next();
					sc.close();
					tr.bs.add(i++,bs.substring(4));					
					if((line = br.readLine()) == null)
						return null;
					if(line.startsWith(end))
						break;				
				}while(true);
				return tr;
			}			
		}
		return null;
	}
}


class TransfacReader implements RecordReader{
	
	public Record readRecord(Reader r) throws IOException{
		BufferedReader br = (BufferedReader) r;
		String line = null;
		String start = "AC  M";
		String patP0 = "P0      A"; 
		String patP1 = "NA  "; 
		String patP2 = "BS  "; 
		String end = "//";
		boolean inRecord = false;
		TransfacRecord tr = new TransfacRecord();
		while((line = br.readLine()) != null){
			if(line.startsWith(start)){
				inRecord = true;
				Scanner sc = new Scanner(line); sc.next();
				tr.ac = sc.next(); sc.close();
			}		
/////////////////////////////////////////////////////////////////////////////////////////////////			
			else if(line.startsWith(patP1) && inRecord){
				Scanner sc = new Scanner(line); sc.next();
				tr.na = sc.next(); sc.close();
			}	
			else if(line.startsWith(patP2) && inRecord){
				int i = 0;
				tr.bs = new ArrayList<String>();

				do{
					Scanner sc = new Scanner(line);
					sc.useDelimiter(";");
					String bs = sc.next();
					sc.close();
					tr.bs.add(i++,bs.substring(4));					
					if((line = br.readLine()) == null)
						return null;
					if(line.startsWith("XX"))
						break;				
				}while(true);
			}			
			else if(line.startsWith(patP0) && inRecord){
				int i = 0;
				tr.wm = new ArrayList<double[]>();
				while(true){
					if((line = br.readLine()) == null)
						return null;
					if(line.startsWith("XX"))
						break;
					Scanner sc = new Scanner(line);
					sc.next();
					double[] d = new double[4];
					for(int j=0; j<4; j++)
						d[j] = sc.nextDouble();
					sc.close();
					tr.wm.add(i++,d);					
				}
			}			
//////////////////////////////////////////////////////////////////////////////////////////			
			else if(line.startsWith(end)){
				if(inRecord)
					return tr;
			}
		}
		return null;
	}
}

public class IO{

	public static double[][] readMatrix(BufferedReader br, int row, int col ) throws IOException{
		double[][] d = new double[row][col];
		for(int i=0; i<row; i++){
			String line = br.readLine();
			Scanner sc = new Scanner(line);
			for(int j=0; j<col; j++)
				d[i][j] = sc.nextDouble();
		}
		return d;
	}
	
	public static String printMatrix(double[][] d){
		StringBuffer sb = new StringBuffer();
		DecimalFormat df = new DecimalFormat("#.##");
		for(int i=0; i<d.length; i++){
			sb.append("MT  ");
			for(int j=0; j<d[i].length; j++)
				if(d[i][j]==0)
					sb.append("0.00  ");
				else
					sb.append(df.format(d[i][j])+"  ");
				sb.append("\n");
		}
		return new String(sb);
	}		
	
	public static String printMatrix(int[][] d){
		StringBuffer sb = new StringBuffer();
		for(int i=0; i<d.length; i++){
			sb.append("IT  ");
			for(int j=0; j<d[i].length; j++)
				sb.append(d[i][j]+" ");
				sb.append("\n");
		}
		return new String(sb);
	}	

	public static String printStrings(String[] s){
		char[][] c = new char[s.length][];
		for(int i=0; i<s.length; i++)
			c[i] = s[i].toCharArray();
		return printMatrix(c);
	}	
	
	public static String printMatrix(char[][] c){
		StringBuffer sb = new StringBuffer();
		for(int i=0; i<c.length; i++){
			for(int j=0; j<c[i].length; j++)
				sb.append(c[i][j]);
				sb.append("\n");
		}
		return new String(sb);
	}	
	
	int[][] readGraph(BufferedReader fpg)
	{
		int[][] edge = null;
		try{
			String line = fpg.readLine();
			int nCOL = Integer.parseInt(line);
			edge = new int[nCOL][];

			for(int i=0; i<nCOL; i++)
			{
				line = fpg.readLine();
				StringTokenizer st = new StringTokenizer(line);
				int nROW = Integer.parseInt(st.nextToken());
				edge[i] = new int[nROW];
				for(int j=0; j<nROW; j++)
					edge[i][j] = Integer.parseInt(st.nextToken());
			}
		}catch(IOException e){
			System.out.println(e);
		}
		return edge;
	}
}