import java.util.*;

//Hit, Score, Threshold

abstract class Scorer{
	public Model m;
	abstract public Score likelihood(char[] samp, int start, int end);
}

class DMHLikeScorer extends Scorer{

	public DMHModel m;
	public DMHLikeScorer(DMHModel m){
		super.m = m;
		this.m = m;
	}
	public double scoreCond(char[] samp, int start, int var, int val){
		double score = -(m.adj[var].length-1)*m.prior[var][val]; // Already log values
		for(int i=0; i<m.adj[var].length; i++){
			int r = m.getEdgeCol(m.adj[var]);
			int c = m.getProbRow(m.adj[var],samp,start);
			score += m.WM[r][c]; // Since it is already log2 value
		}
		score = Math.pow(2.0,score);
		return score;
	}
	
	public double scorePos(char[] samp, int start, int n){
		if(samp[start+n]>=m.base[n])
			return Double.NaN;
		double score = 0;
		double[] d = new double[m.base[n]];
		for(int i=0; i<m.base[n]; i++){
			d[i] = scoreCond(samp,start,n,i);
			score += d[i];
		}
		score = d[samp[start+n]]/score;
		return score;
	}
	
	public Score likelihood(char[] samp, int start, int end){ // take care for top-level sum/multiply, one/two scoring, table look up
		double[] score = new double[1];
		for(int n=start; n<end; n++){
			double p = scorePos(samp,start,n);
			score[0] += Math.log(p); // return log values
		}
		//score = Math.exp(score);
		return new Score(score);
	}
}


class DMHPriorScorer extends Scorer{
	DMHModel m;
	public DMHPriorScorer(DMHModel m){
		super.m = m;
		this.m = m;
		m.min = N.min(m.prior);		
	}
	public Score likelihood(char[] samp, int start, int end){ // take care for top-level sum/multiply, one/two scoring, table look up
		double[] score = new double[1];
		for(int n=start; n<end; n++){
			double d = (samp[n]<m.base[n-start])?m.prior[n-start][samp[n]]:m.min[n-start];
			score[0] += d; // return log values
		}
		return new Score(score);
	}	
}



public class Score {
	public double[] score;
	public double sum;
	public Score(double[] score){
		this.score = score;
		this.sum = N.sum(score);
	}
	public boolean greaterThan(Score s){
		boolean b = true;
		for(int i=0; i<score.length; i++)
			if(this.score[i]>s.score[i]==false){
				b = false; break;
			}
		return b;
	}
	
	public static Comparator<Score> getSumComp(){
		return new Comparator<Score>(){
			public int compare(Score s0, Score s1){
				if(s0.sum>s1.sum) return 1;
				else if(s0.sum<s1.sum) return -1;
				else return 0;
			}
		};
	}
	
}

class Hit extends Record{
	public Scorer s;		
	public int pos;
	public Score score;
	public String seqname;
	public char[] seq;
	public char strand;
	public Hit(int pos, Score score){
		this.pos = pos;
		this.score = score;
	}
	public Hit(int pos, Score score, Scorer s){
		this.pos = pos;
		this.score = score;
		this.s = s;
	}
}

class Threshold{
	public Score score;
	public int hits;
	public double sense;
	public double spec;	
	public Threshold(double[] score){
		this.score = new Score(score);
	}
}