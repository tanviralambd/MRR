import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.Vector;
import java.util.regex.Pattern;



public class SelectModelFromIndex {

	String dataRoot;
	String fnameIndex;
	String fnameMatrix;
	String fnameOutputMatrix;
	
	Vector<Integer> vectIndex = new Vector<Integer>();
	
	void withoutinit()
	{
		
		this.dataRoot = "./";
		this.fnameIndex= dataRoot + "allNeg.nonredundant.index";
		this.fnameMatrix=dataRoot + "allNeg.model";
		this.fnameOutputMatrix=dataRoot + "allNeg.nonredundant.model";
		
		
	}
	
	void init(String dRoot, String fnmIndex, String fnmMat, String fnmOut)
	{
		this.dataRoot =dRoot;
		this.fnameIndex= dataRoot + fnmIndex;
		this.fnameMatrix=dataRoot + fnmMat;
		this.fnameOutputMatrix=dataRoot + fnmOut;
	}
	
	void loadIndex()
	{
		try {
			FileInputStream fstream = new FileInputStream(fnameIndex);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

	
			String strLine=null;
			String afterTrim = null;

			int tmpSt,tmpEn;
			while ( (strLine = br.readLine() ) != null ) {
				afterTrim  = strLine.trim();
				if (afterTrim.length() >0)
					vectIndex.add(Integer.parseInt(strLine)  +1 );
			}
			
			br.close(); in.close();  fstream.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	void loadModel()
	{
		Pattern pat = Pattern.compile("[\\s]+");
		StringBuffer buffer = new StringBuffer();
		StringBuffer tmpBuf = new StringBuffer();
		
		
		try {
			FileInputStream fstream = new FileInputStream(fnameMatrix);
			DataInputStream in = new DataInputStream(fstream);
			BufferedReader br = new BufferedReader(new InputStreamReader(in));

			BufferedWriter bwr = new BufferedWriter(new FileWriter(fnameOutputMatrix));
	
			String strLine=null;
			String afterTrim = null;

			int tmpSt,tmpEn;
			int curID= -1;
			while ( (strLine = br.readLine() ) != null ) {
				afterTrim  = strLine.trim();
						
				// blank line
				if (afterTrim.length() <=0){ 
					continue;
				}
				
				// load a Matrix
				if(afterTrim.startsWith("*")){				
					tmpBuf = new StringBuffer();
					tmpBuf.append(afterTrim+"\n");
					for(int i=1; i<=12;i++)
					{
						strLine = br.readLine();
						if(i==1)
						{
							curID = Integer.parseInt( pat.split(strLine)[1]  );
						}
						tmpBuf.append( strLine+ "\n");
					}					
				}
				if ( vectIndex.contains(curID) )
					buffer.append(tmpBuf+"\n");
					
				tmpBuf = null;
			}
			
			bwr.write(buffer+"");
			
			br.close(); in.close();  fstream.close();
			bwr.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	void doProcessing()
	{
		loadIndex();
		loadModel();
	}
	
	public static void main(String[] args) {
		SelectModelFromIndex obj = new SelectModelFromIndex();
		System.out.println("Setting paramter");
		obj.withoutinit();
		
		obj.init(args[0], args[1], args[2], args[3]) ;
		obj.doProcessing();
		
	}
}
