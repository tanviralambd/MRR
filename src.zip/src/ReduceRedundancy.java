//bsub -o out.o -e err.r ''

import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

class ModelCalculator{

	public static void run(String[] param) throws IOException{		
		ArrayList<Record> tfr = (ArrayList<Record>)new RecordFileReader(new DMFReader()).readRecordFile(param[0]);
		BufferedWriter bw = new BufferedWriter(new FileWriter(param[1]));
		for(int i=0; i<tfr.size(); i++){
			TransfacRecord r = (TransfacRecord)tfr.get(i);
			if(r.bs == null) continue;

			char[][] bs = r.getBS();
			int n = 0;
			for(int j=0; j<bs.length; j++){
				bs[j] = N.nc(bs[j]);
				if(bs[j].length > n) 
					n = bs[j].length;
			}
			//int[][] edge = new IndependenceFinder().findDependency(n);
			int[][] edge = new CliqueDependencyFinder().findDependency(n);
			DMHModel m = new DMHModel(n,4,edge);
			m.train(bs);

			DecimalFormat df = new DecimalFormat("0.##");
			bw.write("AC  "+r.ac+"\n");
			bw.write(IO.printMatrix(N.transpose(m.WM)));
			bw.write(IO.printMatrix(m.adj));
			bw.write(""+new TreeMap<Integer,Integer>(m.adjcol));
			bw.write("\n");
		}	
		bw.flush();
		bw.close();
	}
}

class SimilarityCalculator{

	public static void run(String[] param) throws IOException{		
		System.out.println(param[0]);
		
		String fnmDist = param[4];
		String fnmSelectedIndex = param[5];
		
		
		
		ArrayList<Record> tfr = (ArrayList<Record>)new RecordFileReader(new MatrixReader()).readRecordFile(param[0]);
		//N.sh("Reading complete");
		BufferedReader br = new BufferedReader(new FileReader(param[1]));
		DecimalFormat df = new DecimalFormat("#.####");

		double[][] dist = new double[tfr.size()][tfr.size()];
		for(int i=0; i<tfr.size()-1; i++){
			//if(i%100==0) N.sh(i);
			for(int j=i+1; j<tfr.size(); j++){
				TransfacRecord r1 = (TransfacRecord)tfr.get(i);
				TransfacRecord r2 = (TransfacRecord)tfr.get(j);
				/*
				if(r1.bs == null || r2.bs == null) continue;

				char[][] bs = r1.getBS();
				int n = 0;
				for(int k=0; k<bs.length; k++){
					bs[k] = N.nc(bs[k]);
					if(bs[k].length > n) 
						n = bs[k].length;
				}
				int[][] edge = new IndependenceFinder().findDependency(n);
				DMHModel m1 = new DMHModel(n,4,edge);
				m1.train(bs);				

				bs = r2.getBS();
				n = 0;
				for(int k=0; k<bs.length; k++){
					bs[k] = N.nc(bs[k]);
					if(bs[k].length > n) 
						n = bs[k].length;
				}	
				edge = new IndependenceFinder().findDependency(n);
				DMHModel m2 = new DMHModel(n,4,edge);
				m2.train(bs);				
				 */				
				double d = new RCDistCalc(
						   new TransposeDistCalc(
						   new SlideByRowDistCalc(
						   new RowByDistCalc(
						   new CorrelationDistCalc() ),N.MIN,Integer.parseInt(param[2]))))
						   .dist(r1.mat,r2.mat);
				dist[i][j] = dist[j][i] = d; 		
				
//				System.out.println(d);
				
			}
		}

		/*
		 *  NORMALIZE ALL DISTANCE (0,1). 	IF YOU PRINT THIS VALUE BEFORE NORMALIZATION, IT WILL MATCH MATLAB OUTPUT
		 */
		double min = N.min( N.min(dist) );
		double max = N.max( N.max(dist) );

		for(int i=0; i<tfr.size(); i++){
			for(int j=0; j<tfr.size(); j++){
				dist[i][j] = (dist[i][j]-min)/(max-min);
			}
		}

		/*
		 *  Now select ONLY Top rank and exclude similar ones
		 *  rank,
		 *  1 st value : 1st rank motif
		 *  2nd value : 2nd rank motif
		 *  
		 *  
		 *  nth value: nth rank motif
		 */
		double threshold = Double.parseDouble(param[3]);
		ArrayList<Integer> rank = new ArrayList<Integer>();
		String line;
		while((line = br.readLine())!=null)
			rank.add(Integer.parseInt(line));
		//Collections.sort(rank);
		
		
		for(int i=0; i<rank.size()-1; i++){
			for(int j=i+1; j<rank.size(); j++){
				int m = rank.get(i).intValue(); 
				int n = rank.get(j).intValue();
				if(m<0) break;
				if(n<0) continue;
				if(dist[m][n]<threshold) // shorter dist motif is discarded
					rank.set(j,-1);
			}
		}
		
		
//		for(int i=0; i<rank.size(); i++)
//			if(rank.get(i)>=0)
//				System.out.print(rank.get(i)+" ");
//		System.out.println();
		
		writeFiles(rank  , dist, fnmDist , fnmSelectedIndex);
		
		
	}
	
	static void writeFiles(ArrayList<Integer> rank , double[][] dist ,String fnmDist , String fnmSelectedIndex)
	{
		try {
			BufferedWriter bwrDist = new BufferedWriter(new FileWriter(fnmDist));
			
			BufferedWriter bwrSelIndex = new BufferedWriter(new FileWriter(fnmSelectedIndex));
			
			StringBuffer bufSelIndex = new StringBuffer();
			StringBuffer bufDist = new StringBuffer();
			

			for(int i=0; i<rank.size(); i++)
				if(rank.get(i)>=0)
					bufSelIndex.append(rank.get(i)+"\n");
			bwrSelIndex.write(bufSelIndex+"");
			
			System.out.println("Dis dimension"+ dist.length);
			for(int i=0; i<dist.length;i++)
			{
				for(int j=0; j<dist.length;j++)
				{
					bufDist.append(dist[i][j]+"\t");
				}
				bufDist.append("\n");
				
			}
			bwrDist.write(bufDist+"");
			
			
			bwrDist.close();
			bwrSelIndex.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}

	
}