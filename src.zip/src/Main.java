
public class Main {
	public static void main(String[] args){
		
		System.out.println("Taking param for RR");
		
//		String  minNtToKeep=args[2]; //"6";
//		String minDist=args[3];//".3";
//		String[] param = {args[0],args[1], args[2] ,   args[3]  , args[4] , args[5]};
		
		String  minNtToKeep="6";
		String minDist=".3";
		String[] param = {"testMatrix.dat","testRank.dat", minNtToKeep ,   minDist  , "all.dist" , "selected.index"};

		
//		String  minNtToKeep="6";
//		String minDist=".3";
//		String[] param = {"allPos.transfac","allPos.ranking", minNtToKeep ,   minDist  , "all.dist" , "selected.index"};
	

		try{
			//SimilarityCalculator.run(args);	
			SimilarityCalculator.run(param);	
			//new MotifScanner().run(args);
//			new MotifScanner().run(param);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
