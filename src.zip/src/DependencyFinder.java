
public interface DependencyFinder {
	public int[][] findDependency(Object data);
}

class MarkovDependencyFinder implements DependencyFinder{
	
	public int[][] findDependency(Object data){
		int N = (Integer) data;		
		return findDependency(N,2);
	}	
	
	public int[][] findDependency(int N, int K){
		int nCOL = N-K+1;
		int[][] edge = new int[nCOL][];			

		for(int i=0; i<nCOL; i++)
		{
			int nROW = K;
			edge[i] = new int[nROW];
		}

		for(int i=0; i<N-K+1; i++)
			for(int j=i; j<i+K; j++)
				edge[i][j-i] = j;	
		return edge;
	}
}

class IndependenceFinder implements DependencyFinder{

	public int[][] findDependency(Object data){
		int nCOL = (Integer) data;		
		return findDependency(nCOL);
	}
	
	public int[][] findDependency(int nCOL){
		int[][] edge = new int[nCOL][];			
		for(int i=0; i<nCOL; i++) {
			int nROW = 1;
			edge[i] = new int[nROW];
			edge[i][0] = i;				
		}
		return edge;
	}
}

class CliqueDependencyFinder implements DependencyFinder{
	
	public int[][] findDependency(Object data){
		int N = (Integer) data;		
		return findDependency(N);
	}	
	
	public int[][] findDependency(int N){
		int nCOL = (N*(N-1))/2;
		int[][] edge = new int[nCOL][];			
		
		for(int i=0; i<nCOL; i++){
			int nROW = 2;
			edge[i] = new int[nROW];
		}
		for(int k=0,i=0; i<N-1; i++)
			for(int j=i+1; j<N; j++)
			{
				edge[k][0] = i;
				edge[k][1] = j;
				k++;
			}
		return edge;
	}
}