import java.util.*;

public class N{

	public static final int MAX = 0;
	public static final int MIN = 1;
	public static final int MEAN = 2;	
	
	public static void sh(Object o){
		System.out.println(o);
	}
	
	public static <T> Integer[] sortIndex(final T[] data, final Comparator<T> c){
		Integer[] idx = new Integer[data.length];
		for(int i=0; i<idx.length; i++)
			idx[i] = new Integer(i);
		
		Arrays.sort(idx, new Comparator<Integer>() {
		    @Override public int compare(Integer o1, Integer o2) {
		        return c.compare(data[o1], data[o2]);
		    }
		});
		return idx;
	}
	
	public static double[][] clone(double[][] FM)
	{
		double[][] WM = new double[FM.length][];
		for(int i=0; i<FM.length; i++)
			WM[i] =  Arrays.copyOf(FM[i],FM[i].length);
		return WM;
	}		

	public static double[][] normd(double[][] WM)
	{
		double[] max = max(WM);
		double d = sum(max);
		for(int i=0; i<WM.length; i++)
			div(WM[i], d);
		return WM;
	}

	public static double[][] norms(double[][] WM)
	{
		double[] sum = sum(WM);
		for(int i=0; i<WM.length; i++)
			div(WM[i], sum[i]);
		return WM;
	}

	public static double[] info(double[][] WM)
	{	
		double[] info = new double[WM.length];
		double[] sum = sum(WM); 
		for(int i=0; i<WM.length; i++)
		{			
			double e = 0;
			for(int j=0; j<WM[i].length; j++)
			{
				double p = WM[i][j]/sum[i];
				e += (p>0) ? -p*Math.log(p)/Math.log(2) : 0;
			}
			info[i] = Math.log(WM[i].length)/Math.log(2)-e;  //information-entropy
		}
		return info;
	}	


	public static double[] add(double[] x, double y){
		for(int i=0; i<x.length; i++)
			x[i] += y;
		return x;
	}

	public static double[] sub(double[] x, double y){
		for(int i=0; i<x.length; i++)
			x[i] -= y;
		return x;
	}

	public static double[] mult(double[] x, double y){
		for(int i=0; i<x.length; i++)
			x[i] *= y;
		return x;
	}

	public static double[] div(double[] x, double y){
		for(int i=0; i<x.length; i++)
			x[i] /= y; // Check for div by zero
		return x;
	}

	public static double log2(double x){
		return Math.log(x)/Math.log(2); // Check for div by zero
	}	
	
	public static double[] log2(double[] x){
		for(int i=0; i<x.length; i++)
			x[i] = Math.log(x[i])/Math.log(2); // Check for div by zero
		return x;
	}	

	public static double[][] log2(double[][] WM)
	{
		for(int i=0; i<WM.length; i++)
			log2(WM[i]);
		return WM;
	}	

	public static double[] pow(double[] x, double p){
		for(int i=0; i<x.length; i++)
			x[i] = Math.pow(x[i],p); // Check for div by zero
		return x;
	}		

	public static double sum(double[] x){
		double d = 0;
		for(int i=0; i<x.length; i++)
			d += x[i];
		return d;
	}
	
	public static double sum(double[] x, double[] w){ // weighted sum
		double d = 0;
		for(int i=0; i<x.length; i++)
			d += x[i]*w[i];
		return d;
	}	

	public static double[] sum(double[][] WM)
	{
		double[] sum = new double[WM.length];
		for(int i=0; i<WM.length; i++)
			sum[i] = sum(WM[i]);
		return sum;
	}		

	public static double avg(double[] x){
		return sum(x)/x.length;
	}	

	public static double median(double[] x){
		double[] d = Arrays.copyOf(x,x.length);
		Arrays.sort(d);
		return d[d.length/2];
	}	

	public static double min(double[] x){
		double d = Double.POSITIVE_INFINITY;
		for(int i=0; i<x.length; i++)
			if(d>x[i])
				d = x[i];
		return d;
	}

	public static double[] min(double[][] WM)
	{
		double[] min = new double[WM.length];
		for(int i=0; i<WM.length; i++)
			min[i] = min(WM[i]);
		return min;
	}		
	
	public static double max(double[] x){
		double d = Double.NEGATIVE_INFINITY;
		for(int i=0; i<x.length; i++)
			if(d<x[i])
				d = x[i];
		return d;
	}	

	public static double[] max(double[][] WM)
	{
		double[] max = new double[WM.length];
		for(int i=0; i<WM.length; i++)
			max[i] = max(WM[i]);
		return max;
	}	

	public static double[] add(double[] x, double[] y){
		double[] sum = new double[x.length];
		for(int i=0; i<x.length; i++) {
			sum[i] = x[i] + y[i];
		}
		return sum;
	}

	public static double[] sub(double[] x, double[] y){
		double[] diff = new double[x.length];
		for(int i=0; i<x.length; i++) {
			diff[i] = x[i] - y[i];
		}
		return diff;
	}		

	public static double[] mult(double[] x, double[] y){
		double[] mult = new double[x.length];
		for(int i=0; i<x.length; i++) {
			mult[i] = y[i] * x[i];
		}
		return mult;
	}			

	public static double[] div(double[] x, double[] y){
		double[] div = new double[x.length];
		for(int i=0; i<x.length; i++) {
			div[i] = (y[i]>0) ? x[i] / y[i] : (x[i]>=0) ? Double.POSITIVE_INFINITY : Double.NEGATIVE_INFINITY;
		}
		return div;
	}			


	public static char[] nc(char[] seq)
	{
		int i=0;
		int len = seq.length;
		while(i<len)
		{
			switch (seq[i])
			{
			case 'a':
			case 'A':
				seq[i] = 0;
				break;
			case 'c':
			case 'C':
				seq[i] = 1;
				break;
			case 'g':
			case 'G':
				seq[i] = 2;
				break;
			case 't':
			case 'T':
				seq[i] = 3;
				break;
			default:
				seq[i] = 4;
				break;
			}
			i++;
		}
		return seq;
	}	


	public static char[] rc(char[] seq)
	{
		int i, j;
		char c, tmp;
		if(seq == null) return seq;
		i = 0;
		j = seq.length-1;
		while (i <= j){
			c = seq[i];
			if(c==0)
				tmp = 3;
			else if(c==3)
				tmp = 0;
			else if(c==1)
				tmp = 2;
			else if(c==2)
				tmp = 1;
			else if(c=='A' || c=='a')
				tmp = 'T';
			else if(c=='T' || c=='t')
				tmp = 'A';
			else if(c=='G' || c=='g')
				tmp = 'C';
			else if(c=='C' || c=='c')
				tmp = 'G';
			else
				tmp = c;
			c = seq[j];
			if(c==0)
				seq[i] = 3;
			else if(c==3)
				seq[i] = 0;
			else if(c==1)
				seq[i] = 2;
			else if(c==2)
				seq[i] = 1;
			else if(c=='A' || c=='a')
				seq[i] = 'T';
			else if(c=='T' || c=='t')
				seq[i] = 'A';
			else if(c=='G' || c=='g')
				seq[i] = 'C';
			else if(c=='C' || c=='c')
				seq[i] = 'G';
			else
				seq[i] = c;
			seq[j] = tmp;
			i++;
			j--;
		}
		return seq;
	}		

	public static double[] unique(double[] d)
	{
		TreeSet<Double> t = new TreeSet<Double>();
		for(int i=0; i<d.length; i++)
			t.add(d[i]);
		double[] u  = new double[t.size()];
		Iterator<Double> it = t.iterator();
		int i = 0;
		while(it.hasNext())
			u[i++] = it.next().doubleValue();
		return u;
	}	

	public static String[] unique(String[] s)
	{
		TreeSet<String> t = new TreeSet<String>();
		for(int i=0; i<s.length; i++)
			t.add(s[i]);
		String[] u  = new String[t.size()];
		Iterator<String> it = t.iterator();
		int i = 0;
		while(it.hasNext())
			u[i++] = it.next();
		return u;
	}	
	
	public static double[][] transpose(double[][] d){
		double[][] t = new double[d[0].length][d.length]; 
        for (int i=0; i<t.length; i++)
            for (int j=0; j<t[0].length; j++)
                t[i][j] = d[j][i];
		return t;
	}
	
	
	public static <T> T[] rev(T[] seq)
	{
		int i, j;
		T temp;
		if(seq == null) return seq;
		i = 0;
		j = seq.length-1;
		while (i <= j){
			temp = seq[i];
			seq[i] = seq[j];
			seq[j] = temp;
			i++;
			j--;
		}
		return seq;
	}			
	
	public static double[] rev(double[] seq)
	{
		int i, j;
		double temp;
		if(seq == null) return seq;
		i = 0;
		j = seq.length-1;
		while (i <= j){
			temp = seq[i];
			seq[i] = seq[j];
			seq[j] = temp;
			i++;
			j--;
		}
		return seq;
	}				

	public static double[][] rc(double[][] d){
		rev(d);
        for (int i=0; i<d.length; i++){
        	double[] t = d[i]; rev(t);
        }
		return d;
	}	

}	

