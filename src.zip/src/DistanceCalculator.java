import java.util.*;

public interface DistanceCalculator {
}

interface VectorDistanceCalculator extends DistanceCalculator{
	public static final double p = 2;
	public double dist(double[] x, double[] y);
}

interface MatrixDistanceCalculator extends DistanceCalculator{
	public double dist(double[][] x, double[][] y);
}

class RCDistCalc implements MatrixDistanceCalculator{
	public MatrixDistanceCalculator mdc;
	public RCDistCalc(MatrixDistanceCalculator mdc){
		this.mdc = mdc;
	}

	/*
	 *  ta
	 * @see MatrixDistanceCalculator#dist(double[][], double[][])
	 */
	public double dist(double[][] x, double[][] y){
		double[][] rx = N.clone(x); N.rc(rx);
		double[][] ry = N.clone(y); N.rc(ry);		
		double[] dists = new double[4];
		dists[0] = mdc.dist(x,y);
		dists[1] = mdc.dist(x,ry);
		dists[2] = mdc.dist(rx,y);
		dists[3] = mdc.dist(rx,ry);
		Arrays.sort(dists);
		return dists[0]; 
	}
}

class TransposeDistCalc implements MatrixDistanceCalculator{
	public MatrixDistanceCalculator mdc;
	public TransposeDistCalc(MatrixDistanceCalculator mdc){
		this.mdc = mdc;
	}

	public double dist(double[][] x, double[][] y){
		double[][] tx = N.transpose(x);
		double[][] ty = N.transpose(y);		
		return mdc.dist(tx,ty);
	}
}

class SlideByRowDistCalc implements MatrixDistanceCalculator{
	public MatrixDistanceCalculator mdc;
	public int distType;
	public int minOverlap;

	
	public SlideByRowDistCalc(MatrixDistanceCalculator mdc, int distType, int minOverlap){
		this.mdc = mdc;
		this.distType = distType;
		this.minOverlap = minOverlap; 
	}

	public double[] slideByRowDist(double[][] x, double[][] y){
		double[][] b = (x.length>=y.length) ? x : y;
		double[][] s = (x.length< y.length) ? x : y;
		int m = s.length;
		int n = b.length;
		int p= this.minOverlap;
		if(p>m)
			p = m;
		double[] dists = new double[n+m-2*p+1]; 
		int j = 0;
		
		// partial overlap
		for(int i=0; i<m-p; i++){
			double[][] t = Arrays.copyOfRange(b, 0, i+p);
			double[][] r = Arrays.copyOfRange(s, m-p-i, m);
			dists[j++] = mdc.dist(t,r);
		}		
		
		for(int i=0; i<n-m+1; i++){
			double[][] t = Arrays.copyOfRange(b, i, i+m);
			dists[j++] = mdc.dist(s,t);
		}
		
		// partial overlap
		for(int i=0; i<m-p; i++){
			double[][] t = Arrays.copyOfRange(b, n-m+1+i, n);
			double[][] r = Arrays.copyOfRange(s, 0, m-1-i);
			dists[j++] = mdc.dist(t,r);
		}		
		
//		for(int c=0 ;   c<dists.length ;c++)
//			System.out.print(dists[c] + "\t");
		
		return dists;
	}

	public double dist(double[][] x, double[][] y){
		double[] dists = slideByRowDist(x,y);
		double dist = 0;
		switch(distType){
		case N.MAX: dist = N.max(dists);
		case N.MIN: dist = N.min(dists);
		}
		return dist;
	}
}

class VectorizedDistCalc implements MatrixDistanceCalculator{
	public VectorDistanceCalculator vdc;
	public VectorizedDistCalc(VectorDistanceCalculator vdc){
		this.vdc = vdc;
	}

	public double dist(double[][] x, double[][] y){
		int len = 0;
		for(int i=0; i<x.length; i++)
			len += x[i].length;

		double[] X = new double[len];
		double[] Y = new double[len]; // exception not equal dimensions

		for(int i=0, k=0; i<x.length; i++)
			for(int j=0; j<x[i].length; j++){
				X[k] = x[i][j];
				Y[k] = y[i][j];
				k++;
			}
		return vdc.dist(X,Y);
	}
}

class RowByDistCalc implements MatrixDistanceCalculator{
	public VectorDistanceCalculator vdc;
	public RowByDistCalc(VectorDistanceCalculator vdc){
		this.vdc = vdc;
	}

	/*
	 *  take the average in all positon between 2 matrix
	 */
	public double[] rowByDist(double[][] x, double[][] y){		
		double[] dists = new double[x.length];  
		for(int i=0; i<x.length; i++){
			dists[i] = vdc.dist(x[i],y[i]);
		}	
		return dists;
	}

	public double dist(double[][] x, double[][] y){
		double[] dists = rowByDist(x,y);
		return N.avg(dists);
	}
}


class HarmonicMeanDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Harmonic
		return - 2*N.sum( N.div( N.mult(x,y), N.add(x,y) ) );
	}	 		
}	

class ChiSquareDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Chi square
		return N.sum( N.div( N.pow( N.sub(x,y), p ), N.add(x,y) ) );
	}			
}

class DivergenceDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Divergence
		return 2*N.sum( N.div( N.pow( N.sub(x,y), p ), N.pow( N.add(x,y), p ) ) );
	}	  	 		
}

class InnerProductDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Inner product
		return -N.sum( N.mult(x,y) );
	}		 		
}

class BhattacharyaDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Bhattacharya
		return -Math.log( N.sum( N.pow( N.mult(x,y), 1/p) ) );
	}		
}

class FidelityDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Fidelity
		return -N.sum( N.pow( N.mult(x,y), 1/p) );
	}		 		
}

class JaccardDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Jaccard
		return new PoweredMinkowskiDistCalc().dist(x,y) / ( N.sum( N.mult(x,x) ) + N.sum( N.mult(y,y) ) );
	}		 		
}

class DiceDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Dice
		return new PoweredMinkowskiDistCalc().dist(x,y) / ( N.sum( N.mult(x,x) ) + N.sum( N.mult(y,y) ) - N.sum( N.mult(x,y) ) );
	}			
}

class CosineDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Cosine
		return - N.sum( N.mult(x,y) ) / Math.sqrt( N.sum( N.mult(x,x) ) * N.sum( N.mult(y,y) ) );
	} 		
}

class MinkowskiDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Minkowski
		return Math.pow( N.sum( N.pow( N.sub(x,y), p ) ), 1/p );
	} 		
}

class PoweredMinkowskiDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Powered Minkowski
		return N.sum( N.pow( N.sub(x,y), p ) );
	}			
}

class ShannonDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Jensen Shanon 
		int len = Math.min(x.length,y.length);
		double d = 0;
		for(int i=0; i<len; i++){
			double addxy = x[i] + y[i];
			double lnx = (x[i]>0) ? x[i]*N.log2(2*x[i]/addxy) : 0;
			double lny = (y[i]>0) ? y[i]*N.log2(2*y[i]/addxy) : 0;
			d += (lnx+lny);
		}
		//return Math.sqrt(d);
		return d;
	}
}

/*
 *  tanvir. chanced  1- corCoeff
 */
class CorrelationDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Correlation
		int n = x.length;
		return 1 - ( n*N.sum( N.mult(x,y) ) - N.sum(x) * N.sum(y) ) / Math.sqrt( ( n*N.sum( N.mult(x,x) ) - N.sum(x) * N.sum(x) ) * ( n*N.sum( N.mult(y,y) ) - N.sum(y) * N.sum(y) ) ); 
	} 		
}

class FuzzyDistCalc implements VectorDistanceCalculator {
	public double dist(double[] x, double[] y) { // Fuzzy
		double[] c1 = x;
		double[] c2 = y;
		int len = c1.length;
		double sim = 0;

		class Data implements Comparable<Data>{
			public int base;
			public double c1;
			public double c2;
			public double h;
			public double u;
			public int compareTo(Data d){
				if(this.h > d.h)    
					return 1;
				else if(this.h < d.h)
					return -1;
				else
					return 0;				
			}
		}

		ArrayList<Data> bases = new ArrayList<Data>();

		for(int i=0; i<len; i++){
			Data d = new Data();
			d.base = i;
			d.c1 = c1[i];
			d.c2 = c2[i];
			d.h =  1 - Math.abs(c1[i]-c2[i]);
			d.u =  Math.max(c1[i],c2[i]);
			bases.add(d);
		}

		Comparator<Data> comparator = Collections.reverseOrder();
		Collections.sort(bases,comparator);

		// Bisection

		double lambda = -1;
		double[] u = new double[len];
		u[0] = bases.get(0).u;
		for(int i=1; i<len; i++){
			double u1 = u[i-1];
			double u2 = bases.get(i).u;
			u[i] = u1 + u2 + lambda*u1*u2;
		}

		sim = Math.min(bases.get(0).h, u[0]);
		//System.out.println(""+bases.get(0).h+"\t"+u[0]);
		for(int i=1; i<len; i++){
			double temp = Math.min(bases.get(i).h, u[i]);
			//System.out.println(""+bases.get(i).h+"\t"+u[i]);
			if(temp>sim)
				sim = temp;
		}
		return -sim;
	}
}


/*
double a = 0, b = -1, fa = 1, fx = 1, x, dx;
int k = 0;
do{
	x = ((a+b)/2);
	for(int i=0; i<len; i++){
		double ui = bases.get(i).u;
		fa *= 1+a*ui; 
		fx *= 1+x*ui;
	}
	fa = fa-1-a;
	fx = fx-1-x;

	if(fa*fx<0) {
		b = x;
		dx = b-a;
	}
	else {
		a = x;
		dx = b-a;
	}
	k++;
}while(Math.abs(dx)>Util.DEL && k<Util.MAXITER && fx!=0);	
 */





