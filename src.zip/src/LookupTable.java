import java.util.*;

public class LookupTable {
	
	public double threshold;
	public BitSet table;
	public int[] pos;
	public static final int wLen = 10;
	public Model m;
	
	public LookupTable(double threshold, Model m){
		this.threshold = threshold;
		int wLen = (m.base.length>LookupTable.wLen)? LookupTable.wLen : m.base.length;
		this.pos = new int[wLen];	
		this.m = m;
	}
	
	public int getInt(char[] seq, int start){
        int p = 0;
        for (int i=0; i<this.pos.length; i++) 
            p = p*m.base[pos[i]] + seq[i];
        return p;
	}

	public void createDMHT()
	{
		DMHModel m = (DMHModel)this.m; 
		double[] max = N.max(m.prior); 
		ArrayList<double[]> pp = new ArrayList<double[]>(max.length);
		for(int i=0; i<max.length; i++)
			pp.add(new double[]{i,max[i]});
		Collections.sort(pp, new Comparator<double[]>(){
			public int compare(double[] d1, double[] d2) {
				return (d1[1]<d2[1])?1:(d1[1]>d2[1])?-1:0;
			}			
		});
		
		double d = N.sum(max);
		for(int i=0; i<this.pos.length; i++){
			double[] prob = pp.get(i); 
			this.pos[i] = (int)prob[0];
			d -= prob[1];
		}
		d = threshold-d;
        
		
		int size = 1;
		for(int i=0; i<pos.length; i++)
			size *= m.base[pos[i]];
		table = new BitSet(size);			

		int[] a = new int[this.pos.length];
		//for(int i=0; i<a.length; i++)
		//for(int count=0; count<table.size(); count++)
		int count = 0;
		while(true)
		{
            double x = 0;
			for(int k=0; k<pos.length; k++){
				x += m.prior[pos[k]][a[k]];
			}
			if(x>d) table.set(count);
			count++;

			int j = this.pos.length-1;
            while(a[j]==(m.base[pos[j]]-1)) {
                a[j] = 0;
                j--;
                if(j<0) return; 
            }
            a[j]++;			
		}
	}	
}
