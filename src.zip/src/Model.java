import java.util.*;

abstract class Model {
	public int[] base; // base number system of random variable 
	public String name;
	public String source;
	public String feature;	
	public Threshold th;
	public LookupTable table;
	public double filter;	
	public abstract Model train(char[][] samp);
}

class DMHModel extends Model{ //Discrete Marginal Hypergraph Model

	public int[][] hedges; // Hypergraph edges
	public int[][] adj; // Adjacency List
	public double[][] WM; // Marginal probability distribution
	public double[][] prior; // Prior probability distribution	
	public HashMap<Integer,Integer> adjcol;
	public double[] min;
	public double[] max;
	
	public DMHModel(int n, int base, int[][] hedges){
		this.base = new int[n];
		Arrays.fill(this.base, base);
		this.hedges = hedges;
		this.adj = getAdjacency(this.base, this.hedges);
		this.adjcol = getColAdjacency(this.hedges);
	}	
	
	public DMHModel(int n, int[][] hedges){
		this.base = new int[n];
		Arrays.fill(this.base, 4);
		this.hedges = hedges;
		this.adj = getAdjacency(this.base, this.hedges);
		this.adjcol = getColAdjacency(this.hedges);
	}	
	
	public DMHModel(int[] base, int[][] hedges){
		this.base = base;
		this.hedges = hedges;
		this.adj = getAdjacency(this.base, this.hedges);
		this.adjcol = getColAdjacency(this.hedges);
	}

	public double[][] getPrior(int[] base, char[][] samp){
		double[][] PFM = new double[base.length][];
		for(int i=0; i<base.length; i++){
			PFM[i] = new double[base[i]];
			Arrays.fill(PFM[i],1); // Pseudo count
		}
        for (int i=0; i<samp.length; i++)
        	for (int j=0; j<base.length; j++)
	        {
	            int m = samp[i][j];
	            if(m<base[j]) PFM[j][m]++;
	        }
        PFM = N.normd(PFM);
        PFM = N.log2(PFM);
		return PFM;
	}
	
	public Model train(char[][] samp){
		this.prior = getPrior(this.base, samp);
		this.WM = new double[hedges.length][];
		for(int i=0; i<hedges.length; i++)
		{
			int n = 1;
			for(int j=0; j<hedges[i].length; j++)
				n *= base[hedges[i][j]];			
			WM[i] = new double[n];
			Arrays.fill(WM[i],1); // Pseudo counts
		}		
		for(int j=0; j<samp.length; j++) // In ith column jth sample is contributing at idx row  
			for(int i=0; i<hedges.length; i++)
			{
				int idx = getProbRow(hedges[i],samp[j],0); 
				if(idx>=0) WM[i][idx]++;
			}
		WM = N.normd(WM);
		WM = N.log2(WM);
		return this;
	}	
	
	public int getEdgeCol(int[] nodes){
		int idx = 0;
		for(int i=0; i<nodes.length; i++)
			idx += i*base.length + nodes[i];
		return adjcol.get(idx);		
	}
	
	public int getProbRow(int[] nodes, char[] samp, int start){
		int idx = 0;
		for(int k=0; k<nodes.length; k++)
		{
			int m = samp[start+nodes[k]];
			if(m>=base[nodes[k]]) {
				idx = -1; break;
			}
			idx = idx*base[nodes[k]] + m;
		}
		return idx;
	}		
	
	public int[][] getAdjacency(int base[], int[][] hedges){
		ArrayList<TreeSet<Integer>> adjList = new ArrayList<TreeSet<Integer>>(base.length); 
		for(int i=0; i<base.length; i++)
			adjList.add(new TreeSet<Integer>());
		
		for(int i=0; i<hedges.length; i++){
			for(int j=0; j<hedges[i].length; j++)
				for(int k=0; k<hedges[i].length; k++){
					if(j==k) continue;
					adjList.get(hedges[i][j]).add(hedges[i][k]);
				}
		}

		int[][] adj = new int[base.length][];
		for(int i=0; i<base.length; i++){
			Object[] temp = adjList.get(i).toArray();		
			adj[i] = new int[temp.length];
			for(int j=0; j<temp.length; j++){
				Integer x = (Integer)temp[j];
				adj[i][j] = x.intValue();
			}
		}
		return adj;
	}
	
	public HashMap<Integer,Integer> getColAdjacency(int[][] hedges){
		HashMap<Integer,Integer> adjcol = new HashMap<Integer,Integer>();
		for(int i=0; i<hedges.length; i++){
			int idx = 0;
			for(int j=0; j<hedges[i].length; j++)
				idx += j*base.length + hedges[i][j];						
			adjcol.put(idx,i);
		}
		return adjcol;
	}	
	
}